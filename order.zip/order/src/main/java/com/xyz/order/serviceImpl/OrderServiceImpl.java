package com.xyz.order.serviceImpl;

import com.xyz.order.dto.OrderDto;
import com.xyz.order.repository.OrderRepository;
import com.xyz.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {


    @Autowired
    OrderRepository orderRepository;

    @Override
    public List<OrderDto> getOrder() {
        return orderRepository.getOrders();
    }
}
