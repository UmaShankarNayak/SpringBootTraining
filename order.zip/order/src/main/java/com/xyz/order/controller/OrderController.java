package com.xyz.order.controller;

import com.xyz.order.dto.OrderDto;
import com.xyz.order.serviceImpl.OrderServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    OrderServiceImpl orderService;

    @GetMapping
    public ResponseEntity<List<OrderDto>> getOrders() {
       return ResponseEntity.ok(orderService.getOrder());
    }

    @PostMapping
    public ResponseEntity<String> getOrders(@RequestBody OrderDto orderDto) {
        return ResponseEntity.ok("Order save successfully");
     //   return ResponseEntity.ok(orderService.getOrder());
    }
}
