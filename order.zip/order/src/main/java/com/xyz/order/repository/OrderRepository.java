package com.xyz.order.repository;

import com.xyz.order.dto.OrderDto;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public class OrderRepository {

    public List<OrderDto> getOrders() {
        return dummyData();
        // from here call to db and get data
    }


    private List<OrderDto> dummyData() {
        //This Data will fetch from database
        return List.of(new OrderDto(101l, 3000.00, new Date(), "any discription"),
                new OrderDto(301l, 4000.00, new Date(), "any discription"),
                new OrderDto(401l, 5000.00, new Date(), "any discription"),
                new OrderDto(141l, 3800.00, new Date(), "any discription"));
    }
}
