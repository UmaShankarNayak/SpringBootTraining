package com.xyz.order.service;

import com.xyz.order.dto.OrderDto;

import java.util.List;

public interface OrderService {

    List<OrderDto> getOrder();

    OrderDto processOrder(OrderDto orderDto);

    OrderDto getOrderById(Integer id);

    OrderDto updateOrder(OrderDto orderDto);
}
