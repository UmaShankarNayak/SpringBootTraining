package com.xyz.order.converter;

import com.xyz.order.dto.OrderDto;
import com.xyz.order.dto.OrderStatus;
import com.xyz.order.entity.OrderEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class OrderConverter {

    public OrderEntity orderDtoToEntity(OrderDto orderDto) {
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setAmount(orderDto.getAmount());
        orderEntity.setProductId(orderDto.getProductId());
        orderEntity.setUserId(orderDto.getUserId());
        orderEntity.setOrderStatus(OrderStatus.COMPLETED);
        return orderEntity;
    }

    public OrderDto orderEntityToDto(OrderEntity orderEntity) {
        OrderDto dto = new OrderDto();
        dto.setId(orderEntity.getId());
        dto.setAmount(orderEntity.getAmount());
        dto.setUserId(orderEntity.getUserId());
        dto.setProductId(orderEntity.getProductId());
        dto.setOrderStatus(OrderStatus.COMPLETED);
        return dto;
    }

    public List<OrderDto> orderEntitiesToDtos(List<OrderEntity> orderEntities) {
        List<OrderDto> orderDtos = new ArrayList<>();
        for (OrderEntity orderEntity: orderEntities) {
            orderDtos.add(orderEntityToDto(orderEntity));
        }

        return orderDtos;
    }
}
