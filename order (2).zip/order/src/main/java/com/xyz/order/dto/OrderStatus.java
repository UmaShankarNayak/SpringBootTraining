package com.xyz.order.dto;

public enum OrderStatus {

    COMPLETED,
    FAILED
}
