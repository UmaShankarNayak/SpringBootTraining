package com.xyz.order.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrderDto {

    private Integer id;
    private String productId;
    private Integer userId;
    private Integer amount;

    private OrderStatus orderStatus;
}
