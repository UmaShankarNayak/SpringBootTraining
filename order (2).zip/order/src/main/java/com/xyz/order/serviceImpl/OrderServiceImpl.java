package com.xyz.order.serviceImpl;

import com.xyz.order.converter.OrderConverter;
import com.xyz.order.dto.OrderDto;
import com.xyz.order.dto.OrderStatus;
import com.xyz.order.entity.OrderEntity;
import com.xyz.order.repository.OrderRepository;
import com.xyz.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {


    @Autowired
    OrderRepository orderRepository;

    @Autowired
    OrderConverter orderConverter;


    @Override
    public List<OrderDto> getOrder() {
        List<OrderEntity> orderDtos = orderRepository.findAll();
        return orderConverter.orderEntitiesToDtos(orderDtos);
    }

    @Override
    public OrderDto processOrder(OrderDto orderDto) {

        // Product MS - verify product, is available or not
        // if user online payment in this
        OrderEntity orderEntity = orderConverter.orderDtoToEntity(orderDto);
        OrderDto dto = orderConverter.orderEntityToDto(orderRepository.save(orderEntity));
       return dto;
    }

    @Override
    public OrderDto getOrderById(Integer id) {
        Optional<OrderEntity> orderEntity = orderRepository.findById(id);
        return orderConverter.orderEntityToDto(orderEntity.get());
    }

    @Override
    public OrderDto updateOrder(OrderDto orderDto) {
         Optional<OrderEntity> orderEntity = orderRepository.findById(orderDto.getId());
         if(orderEntity.isPresent()) {
            orderRepository.save(orderConverter.orderDtoToEntity(orderDto));
            return orderDto;
         }
        return null;
    }


}
