package com.xyz.order.controller;

import com.xyz.order.dto.OrderDto;
import com.xyz.order.serviceImpl.OrderServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping(value = "/order")
@Slf4j
public class OrderController {

    @Autowired
    OrderServiceImpl orderService;

    @PostMapping
    public ResponseEntity<OrderDto> processOrder(@RequestBody OrderDto orderDto) {
        return ResponseEntity.ok( orderService.processOrder(orderDto));
    }

    @GetMapping
    public ResponseEntity<List<OrderDto>> getOrders() {
        return ResponseEntity.ok(orderService.getOrder());
    }

    @GetMapping(path = "{id}") // order/{id}
    public ResponseEntity<OrderDto> getOrderById(@PathVariable("id") Integer id) {
        return ResponseEntity.ok(orderService.getOrderById(id));
    }

    @PutMapping
    public ResponseEntity<OrderDto> updateOrder(@RequestBody OrderDto orderDto) {
        return ResponseEntity.ok(orderService.updateOrder(orderDto));
    }

    //Monday - Put/Delete and other queries. ResponseEt
}
