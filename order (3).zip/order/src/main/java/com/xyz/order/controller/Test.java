package com.xyz.order.controller;

import com.xyz.order.dto.OrderDto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/test")
public class Test {

    @GetMapping
    public ResponseEntity<String> getOrders() {
        return ResponseEntity.ok("successfully......");
    }
}
