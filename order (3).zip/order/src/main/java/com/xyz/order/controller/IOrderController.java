package com.xyz.order.controller;

import com.xyz.order.dto.OrderDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "OrderController", description = "This controller class use to expose and consume order related API's")
public interface IOrderController {

    @Operation(
            summary = "process order", description = "process the order")
    @ApiResponses(
            value = {
                    @ApiResponse(responseCode = "200", description = "successfully process order"),
                    @ApiResponse(responseCode = "404", description = "Bad request"),
                    @ApiResponse(responseCode = "500", description = "something went wrong with app")
            } )
    @PostMapping
    ResponseEntity<OrderDto> processOrder(@RequestBody OrderDto orderDto) ;


    @GetMapping(path = "{id}") // order/{id}
    public ResponseEntity<?> getOrderById(@PathVariable("id") Integer id);


    @PutMapping
    public ResponseEntity<OrderDto> updateOrder(@RequestBody OrderDto orderDto);

    @GetMapping
    public ResponseEntity<List<OrderDto>> getOrders();
}
