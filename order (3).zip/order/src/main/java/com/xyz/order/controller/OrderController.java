package com.xyz.order.controller;

import com.xyz.order.dto.OrderDto;
import com.xyz.order.serviceImpl.OrderServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping(value = "/order")
@Slf4j
public class OrderController implements IOrderController{

    @Autowired
    OrderServiceImpl orderService;

    @Override
    public ResponseEntity<List<OrderDto>> getOrders() {
        //for testing exception handler only..
        int i=  10/0;
        return ResponseEntity.ok(orderService.getOrder());
    }

    @Override
    public ResponseEntity<OrderDto> getOrderById(Integer id) {
        return ResponseEntity.ok(orderService.getOrderById(id));
    }

    @Override
    public ResponseEntity<OrderDto> updateOrder(OrderDto orderDto) {
        return ResponseEntity.ok(orderService.updateOrder(orderDto));
    }

    @Override
    public ResponseEntity<OrderDto> processOrder(OrderDto orderDto) {
       return ResponseEntity.ok( orderService.processOrder(orderDto));
    }

}
